public class User {

    public String uid;
    public String username;
    public String password;

    public String role;
}
