import java.util.Date;

public class Movie {
    int mid;
    public String moviename;
    public String gender;
    public String director;
    public String studio;
    public Integer likes;
    public java.util.Date date;

}
